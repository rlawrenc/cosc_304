const express = require('express');
const router = express.Router();
const { sql, getConnection } = require('../db');
const { escapeHtml, formatCurrency, htmlPage } = require('../html');
const { requireLogin } = require('./auth');

router.get('/', requireLogin, async (req, res) => {
    // TODO: Retrieve total order revenue for each day from ordersummary.
    // Hint: SQL Server supports CAST(orderDate AS date), SUM, and GROUP BY.
    // Use getConnection() and close the pool in a finally block.
    // Display the daily totals in an HTML table.
    res.send(htmlPage('Administrator Report',
        '<h1>Administrator Report</h1><p>TODO: show daily sales totals.</p>' +
        '<p><a href="/">Main Page</a></p>'));
});

module.exports = router;
