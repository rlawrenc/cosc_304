const express = require('express');
const router = express.Router();
const { sql, getConnection } = require('../db');

router.post('/', async (req, res) => {
    const username = typeof req.body.username === 'string' ? req.body.username.trim() : '';
    const password = typeof req.body.password === 'string' ? req.body.password : '';
    let validLogin = false;

    if (username && password) {
        // TODO: Connect using getConnection() and query the customer table.
        // Use @username and @password with pool.request().input(...)
        // to avoid inserting user input directly into SQL.
        // If one customer matches, set validLogin = true.
        // Close the database pool in a finally block.
    }

    if (validLogin) {
        req.session.authenticatedUser = username;
        delete req.session.loginMessage;
        return res.redirect('/');
    }
    // Never grant access until the TODO above is completed.
    delete req.session.authenticatedUser;
    req.session.loginMessage = 'Invalid user ID or password.';
    return res.redirect('/login');
});

module.exports = router;
