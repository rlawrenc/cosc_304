const express = require('express');
const router = express.Router();
const { sql, getConnection } = require('../db');
const { escapeHtml, htmlPage } = require('../html');

router.get('/', async (req, res) => {
    const rawId = req.query.orderId;
    if (typeof rawId !== 'string' || !/^[1-9]\d*$/.test(rawId) ||
        !Number.isInteger(Number(rawId)) || Number(rawId) > 2147483647) {
        return res.status(400).send(htmlPage('Shipment Processing',
            '<h1>Invalid order ID.</h1><p><a href="/">Main Page</a></p>'));
    }
    const orderId = Number(rawId);

    // TODO: Open a connection and create one sql.Transaction(pool).
    // TODO: Retrieve orderproduct rows for this order.
    // TODO: Start a transaction and insert a shipment for warehouse 1.
    // TODO: For each item, check warehouse-1 inventory and deduct its quantity.
    // TODO: Commit only if ALL items can ship; otherwise roll back all changes.
    // TODO: Report shipped quantities or the reason for failure.
    // TODO: Always close the pool. Never commit partial changes.
    res.send(htmlPage('Shipment Processing',
        `<h1>Process Order ${orderId}</h1><p>TODO: implement a shipment transaction.</p>` +
        '<p><a href="/">Main Page</a></p>'));
});

module.exports = router;
