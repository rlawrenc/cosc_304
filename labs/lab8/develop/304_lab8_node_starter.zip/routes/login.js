const express = require('express');
const router = express.Router();
const { escapeHtml, htmlPage } = require('../html');

router.get('/', (req, res) => {
    const message = req.session.loginMessage;
    delete req.session.loginMessage;
    const body = `<h1>Log In</h1>
        ${message ? `<p>${escapeHtml(message)}</p>` : ''}
        <form method="post" action="/validateLogin">
        <p><label>User ID: <input name="username" maxlength="20" required></label></p>
        <p><label>Password: <input type="password" name="password" maxlength="30" required></label></p>
        <p><button type="submit">Log In</button></p></form>
        <p><a href="/">Main Page</a></p>`;
    res.send(htmlPage('Log In', body));
});

module.exports = router;
