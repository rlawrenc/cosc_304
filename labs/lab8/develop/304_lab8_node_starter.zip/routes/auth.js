// Lab 8: shared session-based login check for protected pages.
function requireLogin(req, res, next) {
    if (!req.session.authenticatedUser) {
        req.session.loginMessage = 'Please log in to access this page.';
        return res.redirect('/login');
    }
    next();
}

module.exports = { requireLogin };
