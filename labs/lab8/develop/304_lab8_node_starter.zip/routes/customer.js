const express = require('express');
const router = express.Router();
const { sql, getConnection } = require('../db');
const { escapeHtml, htmlPage } = require('../html');
const { requireLogin } = require('./auth');

router.get('/', requireLogin, async (req, res) => {
    const username = req.session.authenticatedUser;
    // TODO: Use a parameterized query to find this customer by userid.
    // Display appropriate customer information (not the password).
    // Use getConnection() and close the pool in a finally block.
    res.send(htmlPage('Customer Information',
        '<h1>Customer Information</h1>' +
        `<p>TODO: show details for ${escapeHtml(username)}.</p>` +
        '<p><a href="/">Main Page</a></p>'));
});

module.exports = router;
