const express = require('express');
const router = express.Router();
const { sql, getConnection } = require('../db');

router.get('/', async (req, res) => {
    const rawId = req.query.id;
    if (typeof rawId !== 'string' || !/^[1-9]\d*$/.test(rawId) ||
        !Number.isInteger(Number(rawId)) || Number(rawId) > 2147483647) {
        return res.status(400).send('Invalid product ID.');
    }
    const productId = Number(rawId);

    // TODO: Retrieve productImage (VARBINARY(MAX)) from the product table
    // using a parameterized query and getConnection().
    // If no image exists, respond with 404.
    // Otherwise send the image bytes, NOT text:
    //     res.type('jpeg').send(imageBytes);
    // Close the database pool in a finally block.
    res.status(501).send(`TODO: stream the database image for product ${productId}.`);
});

module.exports = router;
