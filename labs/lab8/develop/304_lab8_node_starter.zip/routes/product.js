const express = require('express');
const router = express.Router();
const { sql, getConnection } = require('../db');
const { escapeHtml, formatCurrency, htmlPage } = require('../html');

router.get('/', async (req, res) => {
    const rawId = req.query.id;
    if (typeof rawId !== 'string' || !/^[1-9]\d*$/.test(rawId) ||
        !Number.isInteger(Number(rawId)) || Number(rawId) > 2147483647) {
        return res.status(400).send(htmlPage('Product Details',
            '<h1>Invalid product ID.</h1><p><a href="/listprod">Continue Shopping</a></p>'));
    }
    const productId = Number(rawId);

    // TODO: Use a parameterized SQL query with productId to retrieve
    // product name, price, description, productImageURL and productImage.
    // Display the details and both kinds of image when present.
    // A URL image can use /img/1.jpg; a database image should use
    // <img src="/displayImage?id=1"> (substitute the product's actual ID).
    // Add links to /addcart and /listprod (Continue Shopping).
    // Remember to escape text from the database in HTML.
    res.send(htmlPage('Product Details',
        `<h1>Product ${productId}</h1><p>TODO: show product details and images.</p>` +
        '<p><a href="/listprod">Continue Shopping</a></p>'));
});

module.exports = router;
