const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
    // Remove the login only. Keep the Lab 7 shopping cart in the session.
    delete req.session.authenticatedUser;
    res.redirect('/');
});

module.exports = router;
