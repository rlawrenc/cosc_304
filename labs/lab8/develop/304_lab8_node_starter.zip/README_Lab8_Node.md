# COSC 304 — Lab 8 Node.js/Express starter add-on

This package adds **Lab 8 Express routes and product images** to your existing Lab 7 Node.js web store. It is **not a standalone project**.

## Install

1. Start with your **existing** `cosc304-node` Lab 7 project. Do not reset the SQL Server database.
2. If you customized your Lab 7 home page or Express setup, **save copies of `server.js` and `views/index.html` first**. This ZIP contains updated versions of both files and **replaces the Lab 7 versions**. Transfer any custom store name or changes you wish to keep.
3. Extract the *contents* of this ZIP **directly into your existing Node.js project directory** (the folder containing `server.js` and `package.json`). Merge `routes/`, `views/` and `public/img/`, and allow **`server.js` and `views/index.html` to be overwritten**. Keep your existing Lab 7 `db.js`, `html.js`, other routes, Docker configuration, `package.json`, and DDL files unchanged.
4. The new home page links to shopping, order history, login/logout, customer information, administrator reporting, and shipment test links for orders 1 and 3. Update `YOUR NAME Grocery` in `views/index.html` to your store name.
5. Edit your **existing** `routes/listprod.js` so each product name links to `/product?id=<productId>`. Retain its existing Add to Cart link. The starter does **not** replace `routes/listprod.js`.
6. Complete the TODOs in the new Lab 8 route files. The lab instructions are at https://github.com/rlawrenc/cosc_304/blob/main/labs/lab8/develop/README.md.

Start the existing Docker application and visit **http://localhost/**. The Node app listens on port 3000 inside Docker, mapped to port 80 on your computer. You do not need to reload SQL Server or rebuild the database. Because the Lab 8 version registers additional routes in `server.js`, **restart the Node app** if necessary. With the Lab 7 bind-mounted source and dev watcher, changes may reload automatically.

## New files provided

| File | Purpose |
| --- | --- |
| `server.js` | **Replaces the Lab 7 Express entry point**; retains all Lab 7 routes, registers Lab 8 routes, serves image files and displays the current username |
| `views/index.html` | **Replaces the Lab 7 home page**; adds Lab 8 navigation and login-status placeholders |
| `routes/admin.js` | TODO: login-protected daily sales report |
| `routes/auth.js` | Shared session login-check middleware |
| `routes/customer.js` | TODO: details of the logged-in customer |
| `routes/displayImage.js` | TODO: stream a product's binary database image |
| `routes/login.js` | Login form |
| `routes/logout.js` | Logout while preserving the Lab 7 shopping cart |
| `routes/product.js` | TODO: product details, URL image, database image and cart link |
| `routes/ship.js` | TODO: process all ordered products in one shipment transaction |
| `routes/validateLogin.js` | TODO: verify username/password using a parameterized query |
| `public/img/1.jpg`, `1_a.jpg`, `2.jpg`, `3.jpg`, `4.jpg`, `5.jpg` | Product photos from the Java and Python Lab 8 starter files, served at `/img/` |

**Starter behavior:** Lab 7 shopping and order routes remain available, and the new home page, login form, and logout route work immediately. Login intentionally **fails until `routes/validateLogin.js` is completed**. Product, daily sales, customer, database-image and shipment features remain incomplete until students implement the TODOs. The Lab 7 database already has both image fields; **do not reload it** for Lab 8.

**Node.js-specific notes:** Use `mssql` requests with `.input('id', sql.Int, value)` rather than JDBC's `PreparedStatement` class. The Java page `product.jsp?id=1` corresponds to **`/product?id=1`** in Node.js; `ship.jsp?orderId=1` corresponds to **`/ship?orderId=1`**. The Express session stores both the existing `productList` cart and the new `authenticatedUser` login without affecting one another. The new `server.js` uses built-in Node modules and the dependencies already installed in Lab 7.
