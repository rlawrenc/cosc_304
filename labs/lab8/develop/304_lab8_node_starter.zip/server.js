const express = require('express');
const session = require('express-session');
const path = require('path');
const fs = require('fs/promises');
const { escapeHtml } = require('./html');

const app = express();

// Continue using the Lab 7 shopping cart and session configuration.
// This in-memory session store is suitable only for the local course lab.
app.use(express.urlencoded({ extended: false }));
app.use(session({
    secret: process.env.SESSION_SECRET || 'cosc304-local-lab-session-secret',
    resave: false,
    saveUninitialized: false,
    cookie: { httpOnly: true, sameSite: 'lax', secure: false }
}));

// Lab 8: make public/img/1.jpg available at /img/1.jpg.
app.use('/img', express.static(path.join(__dirname, 'public', 'img')));

// Lab 8: show new links and the current username on the main page.
// The home page is still in views/index.html; replace two placeholders
// with escaped session-dependent content before sending it.
app.get('/', async (req, res) => {
    try {
        const page = await fs.readFile(path.join(__dirname, 'views', 'index.html'), 'utf8');
        const username = req.session.authenticatedUser;
        const accountLink = username
            ? '<h2 style="text-align:center"><a href="/logout">Log Out</a></h2>'
            : '<h2 style="text-align:center"><a href="/login">Login</a></h2>';
        const status = username
            ? `<h3 style="text-align:center">Signed in as: ${escapeHtml(username)}</h3>`
            : '';
        res.type('html').send(page.replace('<!-- ACCOUNT_LINK -->', accountLink)
            .replace('<!-- LOGIN_STATUS -->', status));
    } catch (err) {
        console.error('Unable to load the store home page:', err);
        res.status(500).send('Unable to load the store home page.');
    }
});

// Existing Lab 7 routes (keep their files unchanged).
app.use('/loaddata', require('./routes/loaddata'));
app.use('/listorder', require('./routes/listorder'));
app.use('/listprod', require('./routes/listprod'));
app.use('/addcart', require('./routes/addcart'));
app.use('/showcart', require('./routes/showcart'));
app.use('/checkout', require('./routes/checkout'));
app.use('/order', require('./routes/order'));

// New Lab 8 routes.
app.use('/login', require('./routes/login'));
app.use('/validateLogin', require('./routes/validateLogin'));
app.use('/logout', require('./routes/logout'));
app.use('/admin', require('./routes/admin'));
app.use('/customer', require('./routes/customer'));
app.use('/product', require('./routes/product'));
app.use('/displayImage', require('./routes/displayImage'));
app.use('/ship', require('./routes/ship'));

app.listen(3000, () => console.log('COSC 304 store listening on port 3000'));
