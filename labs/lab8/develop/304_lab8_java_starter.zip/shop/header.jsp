<header style="text-align:center">
    <h1><a href="index.jsp">YOUR NAME Grocery</a></h1>
</header>
<hr>
