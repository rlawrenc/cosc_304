<!DOCTYPE html>
<html>
<head>
<title>Ray's Grocery - Product Information</title>
</head>
<body>

<?php 
    include 'header.php';
    include 'include/db_credentials.php';
?>

<?php
// Get product name to search for
// TODO: Retrieve and display info for the product
// $id = $_GET['id'];

$sql = "";

// TODO: If there is a productImageURL, display using IMG tag

// TODO: Retrieve any image stored directly in database. Note: Call displayImage.php with product id as parameter.

// TODO: Add links to Add to Cart and Continue Shopping
?>
</body>
</html>