<html>
<head>
<title>Ray's Grocery Shipment Processing</title>
</head>
<body>

<?php

	// TODO: Get order id      
	// TODO: Check if valid order id
	
	// TODO: Start a transaction 
	
	// TODO: Retrieve all items in order with given id
	// TODO: Create a new shipment record.
	// TODO: For each item verify sufficient quantity available in warehouse 1.
	// TODO: If any item does not have sufficient inventory, cancel transaction and rollback. Otherwise, update inventory for each item.
	
	// TODO: Make sure to commit or rollback active transaction
	
?>

<h2><a href="shop.html">Back to Main Page</a></h2>

</body>
</html>
