<?php 
    include 'auth.php';	
	$user = $_SESSION['authenticatedUser'];
?>

<!DOCTYPE html>
<html>
<head>
<title>Customer Page</title>
</head>
<body>

<?php     
    include 'header.php';
    include 'include/db_credentials.php';
?>

<?php
// TODO: Print Customer information

// Make sure to close connection
?>
</body>
</html>