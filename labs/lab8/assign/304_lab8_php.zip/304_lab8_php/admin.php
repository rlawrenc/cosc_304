<!DOCTYPE html>
<html>
<head>
<title>Administrator Page</title>
</head>
<body>

<?php 
// TODO: Include files auth.php and include/db_credentials.php
?>

<?php
// TODO: Write SQL query that prints out total order amount by day
?>
</body>
</html>