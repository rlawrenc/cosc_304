<h1 align="center"><font face="cursive" color="#3399FF"><a href="index.php">Ray's Grocery</a></font></H1>      
<hr>
