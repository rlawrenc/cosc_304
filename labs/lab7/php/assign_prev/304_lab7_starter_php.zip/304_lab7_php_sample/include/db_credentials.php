<?php
	$username = "<INSERT YOUR USERNAME>";
	$password = "<YOUR PASSWORD>";
	$database = "db_" . $username;
	$server = "sql04.ok.ubc.ca";
	$connectionInfo = array( "Database"=>$database, "UID"=>$username, "PWD"=>$password, "CharacterSet" => "UTF-8");
?>