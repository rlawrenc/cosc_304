<?php
	$username = "SA";
	$password = "YourStrong@Passw0rd";
	$database = "tempdb";
	$server = "db";
	$connectionInfo = array( "Database"=>$database, "UID"=>$username, "PWD"=>$password, "CharacterSet" => "UTF-8");
?>