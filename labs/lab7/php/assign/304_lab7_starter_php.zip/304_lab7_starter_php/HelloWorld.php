<html>
<head>
<title>Hello World in PHP</title>
</head>
<body>

<?php echo("Hello World!"); ?>

</body>
</html>
