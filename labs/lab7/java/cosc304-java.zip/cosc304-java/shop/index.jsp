<!DOCTYPE html>
<html>
<head>
        <title>YOUR NAME Grocery Main Page</title>
</head>
<body>
<h1 align="center">Welcome to YOUR NAME Grocery</h1>

<h2 align="center"><a href="listprod.jsp">Begin Shopping</a></h2>

<h2 align="center"><a href="listorder.jsp">List All Orders</a></h2>

</body>
</html>
